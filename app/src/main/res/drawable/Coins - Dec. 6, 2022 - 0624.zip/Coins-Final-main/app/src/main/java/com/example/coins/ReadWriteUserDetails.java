package com.example.coins;

public class ReadWriteUserDetails {
    public String email;

    public ReadWriteUserDetails(String email) {
        this.email = email;
    }

    public ReadWriteUserDetails() {

    }

    public String getEmail() {
        return email;
    }
}


